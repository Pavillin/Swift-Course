import Cocoa

var str = "Hello, playground"
var number = 10
print("Hello Welcome to Swift")
//normal comment
/*
 multi
 line
 comment
 */

print("\(str), this is the static part of the text") //example of string interpolation


var number2 = 40
var sum = number + number2
print(number + number2)
print(100 - 40)
let age = 20
var name:String = "Swift" //explicit var declaration
var name2 = "Swift"


